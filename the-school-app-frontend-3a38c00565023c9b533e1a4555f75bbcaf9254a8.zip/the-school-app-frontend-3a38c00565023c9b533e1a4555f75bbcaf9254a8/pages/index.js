import { Button } from "antd";
import React from "react";

export default function index() {
  return <Button>Test</Button>;
}
